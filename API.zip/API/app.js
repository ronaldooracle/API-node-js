const conexao = require('./repository/Conexao');
const express = require('express');
var app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.json());


app.delete('/produtos', (req, res) => {
    console.log(req.body.id);
    const dell = require('./controllher/Delete');
    const p = new dell();
    p.SetIdDelete = req.body.id;
    res.send({
        id: p.GetId,
        status: 'Deletado com sucess'
    });


});

app.post('/produtos', (req, res) => {

    const insert = require('./controllher/Post');
    const  p = new insert();
    console.log(p.GetId,p.GetProd,p.GetMar,p.GetTip);
    p.Into  = ([req.body.id,req.body.produto,req.body.marca,req.body.tipo]);

    res.send({
        id: p.GetId,
        produto: p.GetProd,
        marca: p.GetMar,
        tipo: p.GetTip,
        status: 'Inserido com sucesso'
    });

});

app.put('/produtos', (req, res) => {
    const UpDat = require('./controllher/Put');
    const p = new UpDat();
    p.Update = [req.body.id,req.body.produto,req.body.marca,req.body.tipo];
    res.send({
        id: p.GetId,
        produto: p.GetProd,
        marca: p.GetMar,
        tipo: p.GetTip,
        status: 'Update com sucess'
    });



});

app.get('/produtos', (req, res) => {
    const Listar = require('./controllher/Get');
    const p = new Listar();
    console.log(p.Listar);

});
app.get('/produtos/:id', (req, res) => {
    conexao.query('SELECT * FROM produtos WHERE id = ?', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    })

});

//servidor de api iniciado
app.listen(3000, () => console.log('Express server is runnig at port no : 3000'));




