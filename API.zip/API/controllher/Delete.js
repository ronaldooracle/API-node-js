const conexao = require("../repository/Conexao");

class dell{

    constructor(id) {
          this.id = id;
    }
    set SetIdDelete(value){
        this.id  = value;

        const sql = "delete from produtos where id = '"+value+"'";
        conexao.query(sql, function(err, result)  {
            if(!err)

                console.log("Deletado com sucesso "+  value);

            else
                console.log("Erro ao Deletado produto ")

        });

     }
     get GetId(){
        return this.id;
     }

}
module.exports = dell;


