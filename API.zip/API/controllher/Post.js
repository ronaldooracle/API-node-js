const conexao = require('../repository/Conexao');

class insert {

    constructor(id,produto,marca,tipo) {
        this.id = id
        this.produto = produto
        this.marca = marca
        this.tipo = tipo
    }
    get GetId(){
         return this.id;
    }
    get GetProd(){
        return this.produto;
    }
    get GetMar(){
        return this.marca;
    }
    get GetTip(){
        return this.tipo;
    }
    set Into ([a, b, c, d]){
         this.id = a;
         this.produto = b;
         this.marca = c;
         this.tipo = d;

            const sql = "INSERT INTO `produtos`(`id`,`produto`, `marca`,`tipo`) VALUES ('" +this.id+ "','" +this.produto+ "','" +this.marca+ "','" +this.tipo+ "')"
            conexao.query(sql, function (err, result) {
                if (!err)

                    return console.log("Produto Inserido com sucesso " + JSON.stringify(err, undefined, 2));
                else
                    return console.log("Erro ao Inserir Produto ");

            });
        }



}



module.exports = insert;





