const conexao = require('../repository/Conexao');


class UpDat {

    constructor(id,produto,marca,tipo) {
        this.id = id;
        this.produto = produto;
        this.marca = marca;
        this.tipo = tipo;

    }

    set Update([a,b,c,d]){
        this.id = a;
        this.produto = b;
        this.marca = c;
        this.tipo = d;
        let result='Concluido';
        var sql='UPDATE `produtos` SET `produto`="'+this.produto+'",`marca`="'+this.marca+'",`tipo`="'+this.tipo+'" WHERE id="'+this.id+'"';
        conexao.query(sql,function (err,result){
            if(!err)

                console.log(" Update Concluido ");

            else
                console.log("Erro no Update");
        })


    }
    get GetId(){
        return this.id;
    }
    get GetProd(){
        return this.produto;
    }
    get GetMar(){
        return this.marca;
    }
    get GetTip(){
        return this.tipo;
    }
}
module.exports = UpDat;
