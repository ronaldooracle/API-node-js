const conexao = require('../repository/Conexao');

class Listar {
        constructor(list) {
            this.list;
        }

        get Listar() {

            const sql = 'SELECT * FROM `produtos` ';

            conexao.query(sql,(err, result) => {
                if (!err)
                    this.list= result;
                else
                    console.log(err);
            })
            return this.list;
        }
    }

module.exports = Listar;
